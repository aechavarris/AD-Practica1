Este conjunto de pruebas ha sido generado de forma aleatoria usando 
el programa crearPruebas.cpp incluido en este mismo .zip.

La forma de utilizarlo es pasarle como parametros el tamaño minimo, 
el tamaño maximo y la velocidad con la que aumenta el tamaño de las pruebas:

    Usage: ./crearPruebas [minDimension] [maxDimension] [incremento]

Por ejemplo para generar 20 ficheros de prueba entre 5 y 1000 seria algo 
asi:

    ./crearPruebas 5 1000 1.35

Los ficheros de prueba son creados aleatoriamente cada vez que se ejecuta 
este programa.